<p <?php echo e($attributes->class(['filament-tables-header-description'])); ?>>
    <?php echo e($slot); ?>

</p>
<?php /**PATH C:\xampp\htdocs\SIDELINE PROJECTS\AttendanceMonitoring\vendor\filament\tables\src\/../resources/views/components/header/description.blade.php ENDPATH**/ ?>