<a wire:loading.attr="disabled" wire:loading.class="!cursor-wait" href="http://127.0.0.1:8000/administrator/employee-list" class="outline-none inline-flex justify-center items-center group transition-all ease-in duration-150 focus:ring-2 focus:ring-offset-2 hover:shadow-sm disabled:opacity-80 disabled:cursor-not-allowed rounded-full gap-x-2 text-base px-4 py-2     ring-negative-600 text-negative-600 hover:bg-negative-100
    dark:ring-offset-slate-800 dark:hover:bg-slate-700 dark:ring-negative-700 font-semibold">
    
    Cancel

    
    </a>
