<button wire:loading.attr="disabled" wire:loading.class="!cursor-wait" type="button" class="outline-none inline-flex justify-center items-center group transition-all ease-in duration-150 focus:ring-2 focus:ring-offset-2 hover:shadow-sm disabled:opacity-80 disabled:cursor-not-allowed rounded gap-x-2 text-base px-6 py-3     ring-gray-700 text-white bg-gray-700 hover:bg-gray-900 hover:ring-gray-900
    dark:ring-offset-gray-800 dark:bg-gray-700 dark:ring-gray-700
    dark:hover:bg-gray-600 dark:hover:ring-gray-600 w-full">
    
    SUBMIT

            <svg class="w-5 h-5 shrink-0" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 10h10a8 8 0 018 8v2M3 10l6 6m-6-6l6-6" />
</svg>
    
    </button>
<?php /**PATH C:\xampp\htdocs\SIDELINE PROJECTS\AttendanceMonitoring\storage\framework\views/09f2a4c933d345cfc8ac62be21f7501c.blade.php ENDPATH**/ ?>