<div>
    <div class="mt-5">
        <?php echo e($this->table); ?>

    </div>
</div>
<?php /**PATH C:\xampp\htdocs\SIDELINE PROJECTS\AttendanceMonitoring\resources\views/livewire/admin/schedule-list.blade.php ENDPATH**/ ?>