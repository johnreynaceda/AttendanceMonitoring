<div>
    <?php echo e($this->table); ?>

</div>
<?php /**PATH C:\xampp\htdocs\SIDELINE PROJECTS\AttendanceMonitoring\resources\views/livewire/employee/employee-my-attendance.blade.php ENDPATH**/ ?>