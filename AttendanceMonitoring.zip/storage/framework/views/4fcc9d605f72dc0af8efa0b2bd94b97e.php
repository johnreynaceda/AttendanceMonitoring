<div class="ml-4 my-2">
    <img src="<?php echo e(Storage::url($getRecord()->employee->profile_path)); ?>" class="h-20 w-20 object-cover rounded-xl"
        alt="">
</div>
<?php /**PATH C:\xampp\htdocs\SIDELINE PROJECTS\AttendanceMonitoring\resources\views/admin/filament-employee.blade.php ENDPATH**/ ?>