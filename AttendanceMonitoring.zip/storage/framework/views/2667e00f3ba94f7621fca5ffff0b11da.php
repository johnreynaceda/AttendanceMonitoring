<div class="ml-4 my-2">
    <?php if(auth()->user()->is_admin == true): ?>
        <img src="<?php echo e(Storage::url($getRecord()->profile_path)); ?>" class="h-20 w-20 object-cover rounded-xl" alt="">
    <?php else: ?>
        <img src="<?php echo e(Storage::url($getRecord()->employee->profile_path)); ?>" class="h-20 w-20 object-cover rounded-xl"
            alt="">
    <?php endif; ?>
</div>
<?php /**PATH C:\xampp\htdocs\SIDELINE PROJECTS\AttendanceMonitoring\resources\views/admin/employee/filament/photo.blade.php ENDPATH**/ ?>