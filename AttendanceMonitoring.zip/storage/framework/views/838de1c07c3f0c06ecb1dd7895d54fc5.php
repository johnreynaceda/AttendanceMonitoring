<a wire:loading.attr="disabled" wire:loading.class="!cursor-wait" href="http://127.0.0.1:8000/administrator/employee/add-employee" class="outline-none inline-flex justify-center items-center group transition-all ease-in duration-150 focus:ring-2 focus:ring-offset-2 hover:shadow-sm disabled:opacity-80 disabled:cursor-not-allowed rounded gap-x-2 text-sm px-4 py-2     ring-rose-500 text-white bg-rose-500 hover:bg-rose-600 hover:ring-rose-600
    dark:ring-offset-slate-800 dark:bg-rose-700 dark:ring-rose-700
    dark:hover:bg-rose-600 dark:hover:ring-rose-600 font-semibold">
            <svg class="w-4 h-4 shrink-0" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 6v6m0 0v6m0-6h6m-6 0H6" />
</svg>
    
    Add Employee

    
    </a>
<?php /**PATH C:\xampp\htdocs\SIDELINE PROJECTS\AttendanceMonitoring\storage\framework\views/56f4b6cefc8fe8b3c5d03f682747f3c4.blade.php ENDPATH**/ ?>