<button wire:loading.attr="disabled" wire:loading.class="!cursor-wait" type="button" class="outline-none inline-flex justify-center items-center group transition-all ease-in duration-150 focus:ring-2 focus:ring-offset-2 hover:shadow-sm disabled:opacity-80 disabled:cursor-not-allowed rounded gap-x-2 text-base px-6 py-3     ring-gray-700 text-white bg-gray-700 hover:bg-gray-900 hover:ring-gray-900
    dark:ring-offset-gray-800 dark:bg-gray-700 dark:ring-gray-700
    dark:hover:bg-gray-600 dark:hover:ring-gray-600 w-full">
    
    SUBMIT

    
    </button>
<?php /**PATH C:\xampp\htdocs\SIDELINE PROJECTS\AttendanceMonitoring\storage\framework\views/1dab0f06edcad9f775ebfd1ba924ba55.blade.php ENDPATH**/ ?>