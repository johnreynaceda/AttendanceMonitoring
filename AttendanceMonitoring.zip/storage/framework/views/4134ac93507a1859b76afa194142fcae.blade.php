<a wire:loading.attr="disabled" wire:loading.class="!cursor-wait" href="/" class="outline-none inline-flex justify-center items-center group transition-all ease-in duration-150 focus:ring-2 focus:ring-offset-2 hover:shadow-sm disabled:opacity-80 disabled:cursor-not-allowed rounded gap-x-2 text-sm px-4 py-2     bg-white border text-slate-500 hover:bg-slate-50 ring-slate-200
    dark:text-slate-200 dark:ring-slate-700 dark:border-slate-700
    dark:bg-slate-700 dark:hover:bg-slate-600 dark:hover:ring-slate-600
    dark:ring-offset-slate-800">
            <svg class="w-4 h-4 shrink-0" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 10h10a8 8 0 018 8v2M3 10l6 6m-6-6l6-6" />
</svg>
    
    Back Home

    
    </a>
