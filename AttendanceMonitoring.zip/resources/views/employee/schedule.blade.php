@section('title', 'Schedule')
<x-employee-layout>
    <div class="bg-white p-6 rounded-xl shadow">
        <div class="mt-10">
            <livewire:employee.schedule />
        </div>
    </div>
</x-employee-layout>
