@section('title', 'My Attendance')
<x-employee-layout>
    <div class="bg-white p-6 rounded-xl shadow">
        <div class="mt-10">
            <livewire:employee.employee-my-attendance />
        </div>
    </div>
</x-employee-layout>
