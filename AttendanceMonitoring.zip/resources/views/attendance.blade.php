<x-attendance-layout>
    <div>
        <livewire:attendance />
    </div>
</x-attendance-layout>
