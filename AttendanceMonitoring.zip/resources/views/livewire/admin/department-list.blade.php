<div>
    <div class="mt-5">
        {{ $this->table }}
    </div>
</div>
