<div class="ml-4 my-2">
    <img src="{{ Storage::url($getRecord()->employee->profile_path) }}" class="h-20 w-20 object-cover rounded-xl"
        alt="">
</div>
