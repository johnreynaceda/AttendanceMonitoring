<div class=" ">
    <input type="file" name="" wire:model="attachment" id="">
</div>
