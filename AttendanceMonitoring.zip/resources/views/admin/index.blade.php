<x-admin-layout>
    <div>
        <livewire:admin-dashboard />
    </div>
</x-admin-layout>
