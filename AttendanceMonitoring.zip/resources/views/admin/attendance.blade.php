<x-admin-layout>
    <header>
        <h1 class="text-2xl font-semibold text-gray-700 uppercase">
            Attendance
        </h1>
    </header>
    <section class="mt-10">
        <livewire:admin.attendance-list />
    </section>
</x-admin-layout>
